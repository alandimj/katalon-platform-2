<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Level Choose 1</name>
   <tag></tag>
   <elementGuidId>f35323eb-6095-4180-a20e-c7bfa598cca6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body/div[@id='pageWrapper']/div[2]/div[1]/div[3]/div[1]/div[1]/form[1]/span[1]/span[1]/span[2]/ul[1]/li[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
