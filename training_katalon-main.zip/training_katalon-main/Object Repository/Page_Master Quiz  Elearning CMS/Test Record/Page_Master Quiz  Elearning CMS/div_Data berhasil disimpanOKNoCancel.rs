<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Data berhasil disimpanOKNoCancel</name>
   <tag></tag>
   <elementGuidId>ef99db7b-e75c-41c0-8bd9-a2c50d7b5a7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.swal2-container.swal2-center.swal2-backdrop-show</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c4321794-2dac-4a83-92c4-40aad2cc1a7e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>swal2-container swal2-center swal2-backdrop-show</value>
      <webElementGuid>5fab4493-e6f8-435c-8d7e-66d82b015728</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>×
       
       
      
    Data berhasil disimpanOKNoCancel</value>
      <webElementGuid>f38981de-b8d0-4b8d-afff-53f61496fb8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;swal2-shown swal2-height-auto&quot;]/body[@class=&quot;modal-open swal2-shown swal2-height-auto&quot;]/div[@class=&quot;swal2-container swal2-center swal2-backdrop-show&quot;]</value>
      <webElementGuid>7ee7db1a-9c62-4dd6-ae28-db04511191e6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]</value>
      <webElementGuid>cce6f1e5-c0f9-4c0c-b919-18c848e9517d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '×
       
       
      
    Data berhasil disimpanOKNoCancel' or . = '×
       
       
      
    Data berhasil disimpanOKNoCancel')]</value>
      <webElementGuid>2292eec9-a0e3-4435-92c1-752df7fd0a1f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
