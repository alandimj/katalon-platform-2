<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Selamat Datang                        S_5442a5</name>
   <tag></tag>
   <elementGuidId>bf2fe10b-505c-4862-87d8-209ec655a4c8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c855568e-4193-4366-bc88-e1cf81c22a06</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>login-half</value>
      <webElementGuid>65df6465-5fa7-49d8-b8d1-6ce53465c3dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        Selamat Datang!
                        Silahkan masukkan informasi Anda.
                    
                    
                        
                        
                            Email
                            
                        
                        
                            Password
                            
                                
                                
                                    
                                        
                                        
                                    
                                
                            
                        
                        
                            
                                
                                    
                                    Remember me
                                
                                Lupa
                                    Password?
                            
                        
                        
                            Login
                        
                        
                    
                
            </value>
      <webElementGuid>1fa56e84-e0df-4461-9bf4-0ff5f9ead19d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;login-wrapper&quot;]/div[@class=&quot;d-flex flex-row w-100&quot;]/div[@class=&quot;login-half&quot;]</value>
      <webElementGuid>88016542-cdc4-4729-bee2-2dc4f2b9d88d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]</value>
      <webElementGuid>7d675239-9741-4647-b20e-34352d3cbd3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    
                        Selamat Datang!
                        Silahkan masukkan informasi Anda.
                    
                    
                        
                        
                            Email
                            
                        
                        
                            Password
                            
                                
                                
                                    
                                        
                                        
                                    
                                
                            
                        
                        
                            
                                
                                    
                                    Remember me
                                
                                Lupa
                                    Password?
                            
                        
                        
                            Login
                        
                        
                    
                
            ' or . = '
                
                    
                        Selamat Datang!
                        Silahkan masukkan informasi Anda.
                    
                    
                        
                        
                            Email
                            
                        
                        
                            Password
                            
                                
                                
                                    
                                        
                                        
                                    
                                
                            
                        
                        
                            
                                
                                    
                                    Remember me
                                
                                Lupa
                                    Password?
                            
                        
                        
                            Login
                        
                        
                    
                
            ')]</value>
      <webElementGuid>66d95226-81c7-4d03-8e45-7de8a6c5e6b4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
