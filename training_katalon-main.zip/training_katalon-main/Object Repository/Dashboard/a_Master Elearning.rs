<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Master Elearning</name>
   <tag></tag>
   <elementGuidId>72f1cc37-bac8-41c6-93e5-80de471f83d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mainnav']/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c4b71ac4-e019-4604-93e0-fdc4b9f0b498</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link menu-title link-nav </value>
      <webElementGuid>8d3b5d4f-b0ae-4dc0-b1f0-d0579faab9c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://130.211.243.37:96/elearning</value>
      <webElementGuid>e7b8b5f1-f4c8-44e2-a395-0ad0a1b1b62f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                Master Elearning
                            </value>
      <webElementGuid>283cbbbc-4081-4946-9844-edd50921e918</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainnav&quot;)/ul[@class=&quot;nav-menu custom-scrollbar&quot;]/li[@class=&quot;dropdown&quot;]/a[@class=&quot;nav-link menu-title link-nav&quot;]</value>
      <webElementGuid>b6baacdd-75ce-407c-be07-57268437586b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mainnav']/ul/li[3]/a</value>
      <webElementGuid>ac80558d-b8de-4095-914b-ca27dce4c819</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://130.211.243.37:96/elearning']</value>
      <webElementGuid>a7786747-3200-4670-aa11-0eece5585f6d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a</value>
      <webElementGuid>8c6b77ec-9da8-4950-86a4-7dc8ffade13d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://130.211.243.37:96/elearning' and (text() = '
                                Master Elearning
                            ' or . = '
                                Master Elearning
                            ')]</value>
      <webElementGuid>367402bf-1b11-4ec5-930f-ddb9465527ce</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
